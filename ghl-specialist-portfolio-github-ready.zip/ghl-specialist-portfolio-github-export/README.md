# GHL Specialist Portfolio

A polished personal portfolio website positioning **Darious / Da Great** as a GoHighLevel (GHL) CRM and automation specialist.

## Contact

- Email: sumalinogbusiness@gmail.com
- LinkedIn: https://www.linkedin.com/in/darious-sumalinog

## Upload directly to GitHub

1. Create a new repository on GitHub, for example `ghl-specialist-portfolio`.
2. Choose **Private** or **Public** visibility.
3. Open the new repository and select **Add file → Upload files**.
4. Upload the contents of this folder, including the `client`, `server`, `shared`, `package.json`, and `pnpm-lock.yaml` files.
5. Click **Commit changes**.

Keep the `client/public/assets` folder. It contains the local portrait and systems visual used by the site.

## Run locally

This project uses Vite, React, TypeScript, and Tailwind CSS.

```bash
pnpm install
pnpm dev
```

Open the local URL printed by Vite. The production build can be checked with:

```bash
pnpm check
pnpm build
```

## Important files

- `client/src/pages/Home.tsx` — portfolio sections, copy, and contact links
- `client/src/index.css` — visual system, typography, colors, and responsive styling
- `client/public/assets/` — local image assets
- `client/index.html` — page title and SEO description
