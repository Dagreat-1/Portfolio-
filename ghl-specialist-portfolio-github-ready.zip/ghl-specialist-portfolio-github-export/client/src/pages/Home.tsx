import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  Check,
  ChevronDown,
  CircleDot,
  Database,
  GitBranch,
  Linkedin,
  Mail,
  Network,
  Sparkles,
  Zap,
} from "lucide-react";

const services = [
  {
    number: "01",
    title: "CRM Architecture",
    detail: "A clean data foundation built around the way your team actually sells, follows up, and delivers.",
    icon: Database,
  },
  {
    number: "02",
    title: "Automation Systems",
    detail: "Workflows that move leads, trigger the right next step, and make follow-up feel immediate.",
    icon: Zap,
  },
  {
    number: "03",
    title: "Booking & Nurture",
    detail: "Appointment journeys and multi-channel sequences designed to turn intent into attendance.",
    icon: CalendarDays,
  },
  {
    number: "04",
    title: "Pipeline Visibility",
    detail: "Simple reporting layers that surface the conversations, stages, and handoffs that matter.",
    icon: BarChart3,
  },
];

const systemLayers = [
  "Lead capture & qualification",
  "Pipelines, tags & opportunity logic",
  "SMS, email & conversational follow-up",
  "Calendars, reminders & no-show recovery",
];

const process = [
  {
    step: "01",
    title: "Map the motion",
    copy: "We find the friction between a new lead, a booked call, and a closed opportunity.",
  },
  {
    step: "02",
    title: "Build the system",
    copy: "I configure the CRM, workflows, forms, calendars, and conversations around that reality.",
  },
  {
    step: "03",
    title: "Pressure-test",
    copy: "Every path is tested from first touch through the handoff, so details do not get lost.",
  },
  {
    step: "04",
    title: "Refine together",
    copy: "Your team gets a clear operating rhythm and an automation layer ready to keep improving.",
  },
];

function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.24em] text-lime">
      <span className="h-2 w-2 rounded-full bg-lime shadow-[0_0_14px_rgba(215,255,78,0.9)]" />
      {children}
    </div>
  );
}

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden bg-[#090a0d] text-[#f4f4ef] selection:bg-lime selection:text-ink">
      <div className="pointer-events-none fixed inset-0 grid-noise opacity-40" />

      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/8 bg-[#090a0d]/75 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <a href="#top" className="group flex items-center gap-3" aria-label="Darious GHL Systems home">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-lime font-display text-sm font-extrabold text-ink transition-transform duration-200 group-hover:rotate-12">
              D.
            </span>
            <span className="hidden text-[11px] font-bold uppercase tracking-[0.2em] text-white sm:block">
              Darious / Systems
            </span>
          </a>

          <nav className="hidden items-center gap-8 text-[11px] font-bold uppercase tracking-[0.18em] text-white/55 md:flex" aria-label="Primary navigation">
            <a className="transition-colors hover:text-lime" href="#work">Capabilities</a>
            <a className="transition-colors hover:text-lime" href="#services">Services</a>
            <a className="transition-colors hover:text-lime" href="#process">Process</a>
          </nav>

          <a
            href="mailto:sumalinogbusiness@gmail.com?subject=GHL%20system%20project"
            className="inline-flex items-center gap-2 rounded-full border border-lime/45 bg-lime px-4 py-2 text-[10px] font-extrabold uppercase tracking-[0.15em] text-ink transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#f2ff9d] active:scale-[0.97] sm:px-5"
          >
            Start a project <ArrowUpRight size={13} strokeWidth={2.5} />
          </a>
        </div>
      </header>

      <section id="top" className="relative isolate mx-auto min-h-[800px] max-w-[1440px] px-5 pb-16 pt-32 sm:px-8 lg:flex lg:min-h-[920px] lg:items-center lg:px-12 lg:pt-24">
        <div className="pointer-events-none absolute left-[4%] top-[11%] -z-10 h-72 w-72 rounded-full bg-violet/16 blur-[110px]" />
        <div className="pointer-events-none absolute right-[4%] top-[18%] -z-10 h-72 w-72 rounded-full bg-lime/8 blur-[120px]" />

        <div className="relative z-10 max-w-[780px] py-12 lg:w-[60%] lg:py-0">
          <div className="fade-up mb-7 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.24em] text-white/60" style={{ animationDelay: "80ms" }}>
            <span className="h-px w-10 bg-lime" />
            GoHighLevel specialist · CRM & automation
          </div>

          <h1 className="fade-up font-display text-[clamp(3.75rem,8vw,7.75rem)] font-extrabold leading-[0.87] tracking-[-0.075em] text-[#f7f7f2]" style={{ animationDelay: "140ms" }}>
            Build the machine.
            <br />
            <span className="text-lime">Keep the human.</span>
          </h1>

          <p className="fade-up mt-8 max-w-[560px] text-lg leading-relaxed text-white/66 sm:text-xl" style={{ animationDelay: "200ms" }}>
            I design GoHighLevel systems that make the customer journey clearer, the follow-up faster, and your operations easier to run.
          </p>

          <div className="fade-up mt-9 flex flex-wrap items-center gap-4" style={{ animationDelay: "260ms" }}>
            <a
              href="mailto:sumalinogbusiness@gmail.com?subject=GHL%20system%20project"
              className="group inline-flex items-center gap-3 rounded-full bg-white px-6 py-3.5 text-sm font-extrabold text-ink transition-all duration-200 hover:-translate-y-1 hover:bg-lime active:scale-[0.97]"
            >
              Let’s build your system
              <span className="grid h-5 w-5 place-items-center rounded-full bg-ink text-white transition-colors group-hover:bg-white group-hover:text-ink">
                <ArrowUpRight size={13} strokeWidth={2.5} />
              </span>
            </a>
            <a href="#work" className="inline-flex items-center gap-2 text-sm font-bold text-white/65 transition-colors hover:text-lime">
              Explore capabilities <ArrowDownRight size={16} />
            </a>
          </div>

          <div className="fade-up mt-16 grid max-w-[630px] gap-3 border-t border-white/10 pt-5 sm:grid-cols-3" style={{ animationDelay: "320ms" }}>
            {[
              ["CRM", "Structure with purpose"],
              ["Automation", "Follow-up in motion"],
              ["Experience", "Every touch accounted for"],
            ].map(([label, text]) => (
              <div key={label} className="flex items-center gap-3 sm:block">
                <span className="font-display text-xl font-extrabold tracking-[-0.06em] text-lime sm:block">{label}</span>
                <span className="text-xs leading-snug text-white/47">{text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative mt-3 h-[500px] flex-1 sm:h-[620px] lg:mt-0 lg:h-[760px]">
          <div className="absolute inset-x-[7%] bottom-0 top-6 overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-b from-white/[0.08] to-white/[0.01]">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_52%_22%,rgba(215,255,78,0.18),transparent_27%),linear-gradient(150deg,rgba(99,80,244,0.24),transparent_45%)]" />
            <img
              src="/assets/da-great-headshot.png"
              alt="Darious, GoHighLevel CRM and automation specialist"
              className="absolute inset-x-0 bottom-0 h-full w-full object-cover object-center mix-blend-luminosity contrast-125 saturate-[0.8]"
            />
            <div className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-[#090a0d] via-[#090a0d]/35 to-transparent" />
            <div className="absolute inset-x-0 top-0 h-1/3 bg-gradient-to-b from-[#090a0d]/55 to-transparent" />

            <div className="absolute left-5 top-5 flex items-center gap-2 rounded-full border border-white/12 bg-[#121419]/65 px-3 py-2 backdrop-blur-md">
              <CircleDot size={12} className="text-lime" />
              <span className="text-[9px] font-bold uppercase tracking-[0.18em] text-white/75">Systems online</span>
            </div>
            <div className="absolute bottom-5 left-5 right-5 rounded-2xl border border-white/12 bg-[#13151b]/75 p-4 backdrop-blur-xl sm:left-auto sm:w-[258px]">
              <div className="mb-3 flex items-center justify-between text-[9px] font-bold uppercase tracking-[0.17em] text-white/45">
                <span>Focus area</span><span className="text-lime">Live</span>
              </div>
              <p className="font-display text-lg font-bold leading-tight tracking-[-0.035em] text-white">Turning operational complexity into repeatable momentum.</p>
            </div>
          </div>
          <div className="absolute -right-1 top-[18%] hidden h-24 w-24 rounded-full border border-lime/45 lg:block" />
          <div className="absolute -right-6 top-[18%] hidden h-24 w-24 rounded-full border border-violet/45 lg:block" />
        </div>
      </section>

      <section id="work" className="relative border-y border-white/10 bg-[#0d0f13] py-24 sm:py-32">
        <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-12">
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <SectionEyebrow>Systems, not scattered tools</SectionEyebrow>
              <h2 className="mt-5 max-w-md font-display text-5xl font-extrabold leading-[0.92] tracking-[-0.065em] text-white sm:text-6xl">
                The operating layer behind your growth.
              </h2>
            </div>
            <p className="max-w-[560px] text-lg leading-relaxed text-white/58 lg:justify-self-end">
              GoHighLevel becomes powerful when its pieces work together. I connect the capture, conversation, conversion, and continuity layers into one usable system.
            </p>
          </div>

          <div className="mt-14 grid gap-5 lg:grid-cols-12">
            <article className="group relative min-h-[485px] overflow-hidden rounded-[1.75rem] border border-white/10 bg-[#101219] p-6 sm:p-8 lg:col-span-7">
              <img src="/assets/ghl-systems-visual.png" alt="Abstract visualization of connected automation systems" className="absolute inset-0 h-full w-full object-cover object-center opacity-75 transition duration-700 group-hover:scale-105 group-hover:opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#090a0d] via-[#090a0d]/64 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-[#090a0d] via-[#090a0d]/55 to-transparent" />
              <div className="relative flex h-full flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="rounded-full border border-white/15 bg-black/20 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-white/75 backdrop-blur-md">System architecture</span>
                  <Network size={23} className="text-lime" />
                </div>
                <div className="max-w-md">
                  <p className="mb-4 text-[10px] font-bold uppercase tracking-[0.2em] text-lime">From lead to loyal customer</p>
                  <h3 className="font-display text-3xl font-bold leading-none tracking-[-0.05em] text-white sm:text-4xl">Every signal has a next step.</h3>
                  <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/62">Build a connected flow that puts the right information and action in front of your team exactly when it is needed.</p>
                </div>
              </div>
            </article>

            <article className="rounded-[1.75rem] border border-white/10 bg-[#151821] p-6 sm:p-8 lg:col-span-5">
              <div className="flex items-start justify-between">
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-white/75">Journey design</span>
                <GitBranch size={23} className="text-violet" />
              </div>
              <h3 className="mt-14 max-w-sm font-display text-3xl font-bold leading-none tracking-[-0.05em] text-white sm:text-4xl">Make the next best action obvious.</h3>
              <div className="mt-8 rounded-xl border border-white/10 bg-[#0b0d12] p-4">
                <div className="flex items-center gap-2 border-b border-white/10 pb-3 text-[9px] font-bold uppercase tracking-[0.15em] text-white/40">
                  <span className="h-2 w-2 rounded-full bg-lime" /> Customer path
                </div>
                <div className="relative mt-4 space-y-4 before:absolute before:bottom-5 before:left-[11px] before:top-5 before:w-px before:bg-white/10">
                  {[
                    ["New enquiry", "Capture & qualify", "bg-lime"],
                    ["Booked call", "Remind & prepare", "bg-violet"],
                    ["Missed appointment", "Recover & re-engage", "bg-magenta"],
                  ].map(([title, subtitle, color]) => (
                    <div key={title} className="relative flex items-center gap-3">
                      <span className={`relative z-10 h-[23px] w-[23px] rounded-full border-4 border-[#0b0d12] ${color}`} />
                      <div className="flex-1 rounded-lg bg-white/[0.045] px-3 py-2.5">
                        <div className="text-xs font-bold text-white/85">{title}</div>
                        <div className="mt-0.5 text-[10px] text-white/42">{subtitle}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section id="services" className="relative mx-auto max-w-[1440px] py-24 sm:py-32">
        <div className="px-5 sm:px-8 lg:px-12">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <SectionEyebrow>What I build in GHL</SectionEyebrow>
              <h2 className="mt-5 max-w-lg font-display text-5xl font-extrabold leading-[0.92] tracking-[-0.065em] text-white sm:text-6xl">Configured for your actual business.</h2>
            </div>
            <p className="max-w-md text-base leading-relaxed text-white/57">No borrowed templates dropped into a new account. Each system starts with your sales motion, client experience, and operating capacity.</p>
          </div>

          <div className="mt-14 grid border-l border-t border-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {services.map(({ number, title, detail, icon: Icon }) => (
              <article key={title} className="group min-h-[290px] border-b border-r border-white/10 bg-[#0b0c10] p-6 transition-colors duration-300 hover:bg-[#151820] sm:p-7">
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] font-bold tracking-[0.16em] text-white/40">{number}</span>
                  <Icon size={21} className="text-white/55 transition-all duration-300 group-hover:scale-110 group-hover:text-lime" />
                </div>
                <div className="mt-16">
                  <h3 className="font-display text-2xl font-bold tracking-[-0.04em] text-white">{title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-white/55">{detail}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-white/10 bg-[#d7ff4e] py-16 text-ink sm:py-20">
        <div className="mx-auto grid max-w-[1440px] gap-10 px-5 sm:px-8 lg:grid-cols-[0.75fr_1.25fr] lg:px-12">
          <div>
            <div className="flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.22em] text-ink/65"><Sparkles size={14} /> Core belief</div>
            <p className="mt-5 max-w-xs font-display text-3xl font-extrabold leading-[0.95] tracking-[-0.05em]">Good automation gives your team more room to be human.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {systemLayers.map((layer, index) => (
              <div key={layer} className="flex items-center gap-3 border-t border-ink/15 py-3 text-sm font-bold sm:last:border-b">
                <span className="font-mono text-[10px] text-ink/50">0{index + 1}</span>
                <Check size={16} strokeWidth={3} />
                <span>{layer}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="process" className="mx-auto max-w-[1440px] py-24 sm:py-32">
        <div className="px-5 sm:px-8 lg:px-12">
          <div className="grid gap-7 lg:grid-cols-[0.75fr_1.25fr]">
            <div>
              <SectionEyebrow>A clear way forward</SectionEyebrow>
              <h2 className="mt-5 max-w-sm font-display text-5xl font-extrabold leading-[0.92] tracking-[-0.065em] text-white sm:text-6xl">Less guesswork. Better flow.</h2>
            </div>
            <p className="max-w-[560px] text-lg leading-relaxed text-white/58 lg:pt-12">Every engagement is focused on clarity: what needs to happen, who owns it, what triggers it, and how your team can keep it moving.</p>
          </div>

          <div className="mt-16 grid gap-x-8 gap-y-12 border-t border-white/10 pt-7 sm:grid-cols-2 lg:grid-cols-4">
            {process.map(({ step, title, copy }) => (
              <article key={step}>
                <div className="font-mono text-[10px] font-bold tracking-[0.2em] text-lime">{step}</div>
                <h3 className="mt-5 font-display text-2xl font-bold tracking-[-0.04em] text-white">{title}</h3>
                <p className="mt-3 max-w-[245px] text-sm leading-relaxed text-white/52">{copy}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="relative overflow-hidden border-t border-white/10 bg-[#11131a] py-24 sm:py-32">
        <div className="pointer-events-none absolute -right-20 bottom-[-200px] h-[520px] w-[520px] rounded-full border border-lime/25" />
        <div className="pointer-events-none absolute -right-36 bottom-[-270px] h-[660px] w-[660px] rounded-full border border-violet/25" />
        <div className="relative mx-auto grid max-w-[1440px] gap-12 px-5 sm:px-8 lg:grid-cols-[1.25fr_0.75fr] lg:px-12">
          <div>
            <SectionEyebrow>Ready when you are</SectionEyebrow>
            <h2 className="mt-5 max-w-3xl font-display text-[clamp(3.5rem,7vw,6.5rem)] font-extrabold leading-[0.86] tracking-[-0.075em] text-white">
              Let’s make your
              <br /><span className="text-lime">system feel simple.</span>
            </h2>
          </div>
          <div className="self-end rounded-2xl border border-white/10 bg-[#090a0d]/65 p-6 backdrop-blur-sm sm:p-7">
            <Mail size={22} className="text-lime" />
            <p className="mt-6 text-lg font-medium leading-relaxed text-white/75">Have a GHL build, cleanup, or automation problem in mind?</p>
            <a href="mailto:sumalinogbusiness@gmail.com?subject=GHL%20system%20project" className="mt-7 inline-flex items-center gap-3 border-b border-lime pb-1 text-sm font-extrabold text-lime transition hover:gap-5">
              sumalinogbusiness@gmail.com <ArrowUpRight size={16} />
            </a>
            <a href="https://www.linkedin.com/in/darious-sumalinog" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-white/60 transition hover:text-lime">
              <Linkedin size={16} /> LinkedIn / darious-sumalinog
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-[#090a0d] py-7">
        <div className="mx-auto flex max-w-[1440px] flex-col gap-4 px-5 text-[10px] font-bold uppercase tracking-[0.16em] text-white/38 sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
          <span>Darious · GoHighLevel systems specialist</span>
          <a className="transition-colors hover:text-lime" href="https://www.linkedin.com/in/darious-sumalinog" target="_blank" rel="noreferrer">LinkedIn <ArrowUpRight className="ml-1 inline-block" size={12} /></a>
          <a className="transition-colors hover:text-lime" href="#top">Back to top <ChevronDown className="ml-1 inline-block -rotate-180" size={13} /></a>
        </div>
      </footer>
    </main>
  );
}
